# slackbot2
One Paragraph of function description goes here.
## Getting started
### Prerequisites
* [FaaStRuby](https://faastruby.io) version 0.4.18 or higher.
```
# To install
~$ gem install faastruby

# To update
~$ gem update faastruby
```
### How to deploy this function
```
~$ cd FUNCTION_FOLDER
~/FUNCTION_FOLDER$ faastruby deploy-to WORKSPACE_NAME
```
### How to use this function as a template
```
~$ faastruby new FUNCTION_NAME --template github:user/repository
```

